#!/usr/bin/env node
/**
 * 记账本 · 本地服务端 (零依赖)
 *
 * 作用: 让电脑浏览器和手机浏览器访问同一份数据，并实时同步。
 * 只使用 Node.js 内置模块，不需要 npm install。
 *
 * 启动:  node server.js
 * 换端口: set PORT=9000 && node server.js   (Windows)
 */
'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const zlib = require('zlib');

const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
const DATA_DIR = path.join(ROOT, 'data');
const DATA_FILE = path.join(DATA_DIR, 'ledger.json');

const PORT = Number(process.env.PORT || 8787);
const HOST = process.env.HOST || '0.0.0.0';
/** 可选: 设置访问口令后，其它设备需要输入口令才能读写。默认关闭。 */
const ACCESS_CODE = (process.env.ACCESS_CODE || '').trim();
/** 可选: 备案号，设置后网站底部会自动显示 */
const ICP_BEIAN = (process.env.ICP_BEIAN || '').trim();

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8',
  '.woff2': 'font/woff2',
};

// ---------------------------------------------------------------------------
// 数据存储
// ---------------------------------------------------------------------------

const DEFAULT_CATEGORIES = {
  expense: [
    { name: '餐饮', icon: '🍜', color: '#f97316' },
    { name: '交通', icon: '🚕', color: '#3b82f6' },
    { name: '购物', icon: '🛍️', color: '#ec4899' },
    { name: '居住', icon: '🏠', color: '#8b5cf6' },
    { name: '水电燃气', icon: '💡', color: '#eab308' },
    { name: '通讯', icon: '📱', color: '#06b6d4' },
    { name: '娱乐', icon: '🎮', color: '#f43f5e' },
    { name: '医疗', icon: '💊', color: '#14b8a6' },
    { name: '学习', icon: '📚', color: '#6366f1' },
    { name: '人情', icon: '🎁', color: '#d946ef' },
    { name: '旅行', icon: '✈️', color: '#0ea5e9' },
    { name: '运动', icon: '🏃', color: '#22c55e' },
    { name: '宠物', icon: '🐾', color: '#a16207' },
    { name: '其他', icon: '📦', color: '#94a3b8' },
  ],
  income: [
    { name: '工资', icon: '💰', color: '#12a594' },
    { name: '奖金', icon: '🏆', color: '#f59e0b' },
    { name: '兼职', icon: '🧰', color: '#6366f1' },
    { name: '理财', icon: '📈', color: '#0ea5e9' },
    { name: '红包', icon: '🧧', color: '#ef4444' },
    { name: '报销', icon: '🧾', color: '#8b5cf6' },
    { name: '退款', icon: '↩️', color: '#22c55e' },
    { name: '其他', icon: '✨', color: '#94a3b8' },
  ],
};

const DEFAULT_QUICK_NOTES = ['早餐', '午餐', '晚餐', '地铁', '打车', '咖啡', '超市', '外卖', '日用品'];

function sanitizeQuickNotes(input) {
  if (!Array.isArray(input)) return null;
  const out = [];
  for (const raw of input) {
    const text = String(raw == null ? '' : raw).trim().slice(0, 30);
    if (!text || out.indexOf(text) >= 0) continue;
    out.push(text);
    if (out.length >= 30) break;
  }
  return out;
}

let db = {
  rev: 0,
  updatedAt: new Date().toISOString(),
  categories: DEFAULT_CATEGORIES,
  quickNotes: DEFAULT_QUICK_NOTES,
  transactions: [],
};

function loadDb() {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    if (fs.existsSync(DATA_FILE)) {
      const raw = fs.readFileSync(DATA_FILE, 'utf8');
      const parsed = JSON.parse(raw);
      if (parsed && Array.isArray(parsed.transactions)) {
        db = {
          rev: Number(parsed.rev) || 0,
          updatedAt: parsed.updatedAt || new Date().toISOString(),
          categories: sanitizeCategories(parsed.categories) || DEFAULT_CATEGORIES,
          quickNotes: sanitizeQuickNotes(parsed.quickNotes) || DEFAULT_QUICK_NOTES,
          transactions: parsed.transactions
            .map((raw) => sanitizeTx(raw, true))
            .filter(Boolean),
        };
      }
    }
  } catch (err) {
    console.error('[warn] 读取数据文件失败，将以空账本启动:', err.message);
  }
}

let saveTimer = null;
function saveDbSoon() {
  if (saveTimer) clearTimeout(saveTimer);
  saveTimer = setTimeout(saveDbNow, 200);
}
function saveDbNow() {
  saveTimer = null;
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    const tmp = DATA_FILE + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(db, null, 2), 'utf8');
    fs.renameSync(tmp, DATA_FILE);
  } catch (err) {
    console.error('[error] 写入数据文件失败:', err.message);
  }
}

// ---------------------------------------------------------------------------
// 实时同步 (Server-Sent Events)
// ---------------------------------------------------------------------------

const clients = new Set();

function broadcast(event, payload) {
  const chunk = `event: ${event}\ndata: ${JSON.stringify(payload)}\n\n`;
  for (const res of clients) {
    try {
      res.write(chunk);
    } catch {
      clients.delete(res);
    }
  }
}

setInterval(() => {
  for (const res of clients) {
    try {
      res.write(': ping\n\n');
    } catch {
      clients.delete(res);
    }
  }
}, 25000).unref();

// ---------------------------------------------------------------------------
// 工具
// ---------------------------------------------------------------------------

const uid = () => crypto.randomBytes(9).toString('base64url');

function readBody(req, limit = 16 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) {
        reject(new Error('请求体过大'));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => {
      const text = Buffer.concat(chunks).toString('utf8');
      if (!text) return resolve({});
      try {
        resolve(JSON.parse(text));
      } catch {
        reject(new Error('JSON 解析失败'));
      }
    });
    req.on('error', reject);
  });
}

function send(res, status, body, headers = {}) {
  const data = typeof body === 'string' ? body : JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    ...headers,
  });
  res.end(data);
}

function sanitizeCategories(input) {
  if (!input || typeof input !== 'object') return null;
  const out = { expense: [], income: [] };
  for (const key of ['expense', 'income']) {
    const list = Array.isArray(input[key]) ? input[key] : [];
    for (const c of list) {
      if (!c || typeof c !== 'object') continue;
      const name = String(c.name || '').trim().slice(0, 20);
      if (!name) continue;
      const color = String(c.color || '');
      out[key].push({
        name,
        icon: String(c.icon || '📦').slice(0, 4),
        color: /^#[0-9a-fA-F]{6}$/.test(color) ? color : '#94a3b8',
      });
    }
    if (!out[key].length) return null;
  }
  return out;
}

function sanitizeTx(input, lenient) {
  const type = input.type === 'income' ? 'income' : 'expense';
  const amount = Math.round(Number(input.amount) * 100) / 100;
  if (!Number.isFinite(amount) || amount < 0) {
    if (lenient) return null;
    throw new Error('金额无效');
  }
  const rawDate = String(input.date || input.dateTime || '').trim();
  const date = rawDate.slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    if (lenient) return null;
    throw new Error('日期格式无效');
  }
  return {
    id: String(input.id || uid()),
    type,
    amount,
    category: String(input.category || '其他').slice(0, 40),
    date,
    content: String(input.content != null ? input.content : (input.note || '')).slice(0, 200),
    updatedAt: String(input.updatedAt || new Date().toISOString()),
  };
}

function applyOps(ops) {
  const map = new Map(db.transactions.map((t) => [t.id, t]));
  for (const op of ops) {
    if (!op || typeof op !== 'object') continue;
    if (op.op === 'delete') {
      map.delete(String(op.id));
    } else if (op.op === 'setQuickNotes') {
      const notes = sanitizeQuickNotes(op.quickNotes);
      if (!notes) throw new Error('常用内容格式无效');
      db.quickNotes = notes;
    } else if (op.op === 'setCategories') {
      const cats = sanitizeCategories(op.categories);
      if (!cats) throw new Error('分类数据无效');
      db.categories = cats;
    } else if (op.op === 'replaceAll') {
      map.clear();
      for (const item of Array.isArray(op.transactions) ? op.transactions : []) {
        const tx = sanitizeTx(item, true);
        if (tx) map.set(tx.id, tx);
      }
    } else {
      const tx = sanitizeTx(op.tx || op);
      const prev = map.get(tx.id);
      // 简单冲突处理: updatedAt 更晚者胜出
      if (prev && String(prev.updatedAt) > String(tx.updatedAt)) continue;
      map.set(tx.id, tx);
    }
  }
  db.transactions = [...map.values()].sort((a, b) => {
    if (a.date !== b.date) return a.date < b.date ? 1 : -1;
    return String(a.updatedAt) < String(b.updatedAt) ? 1 : -1;
  });
  db.rev += 1;
  db.updatedAt = new Date().toISOString();
  saveDbSoon();
}

// ---------------------------------------------------------------------------
// 自动更新：程序定期到固定网址检查版本，发现新版就自动下载并替换程序文件
// 配置文件：同目录下的 update.json  { "checkUrl": "https://.../version.json" }
// ---------------------------------------------------------------------------

const APP_VERSION = 'v0.18';
const UPDATE_CONFIG_FILE = path.join(ROOT, 'update.json');
const UPDATE_ALLOW = [
  /^server\.js$/,
  /^public\//,
  /^tray\.ps1$/,
  /^start\.ps1$/,
  /^update\.ps1$/,
  /^app\.ico$/,
  /^update\.json$/,
  /^导入模板\.csv$/,
  /^使用说明\.txt$/,
  /^README\.md$/,
  /^启动记账本.*\.bat$/,
  /^更新程序\.bat$/
];

function readUpdateConfig() {
  try {
    if (fs.existsSync(UPDATE_CONFIG_FILE)) {
      const cfg = JSON.parse(fs.readFileSync(UPDATE_CONFIG_FILE, 'utf8'));
      const list = [];
      if (Array.isArray(cfg.checkUrls)) {
        for (const u of cfg.checkUrls) {
          const v = String(u || '').trim();
          if (v) list.push(v);
        }
      }
      const single = String(cfg.checkUrl || '').trim();
      if (single && list.indexOf(single) < 0) list.push(single);
      return { checkUrls: list, autoCheck: cfg.autoCheck !== false };
    }
  } catch (err) {
    console.error('[warn] update.json 读取失败:', err.message);
  }
  return { checkUrls: [], autoCheck: true };
}

/** jsDelivr 对分支地址有缓存，检查前先请求一次它的清除接口 */
async function purgeCdn(url) {
  if (!/^https:\/\/cdn\.jsdelivr\.net\//.test(url)) return;
  const purgeUrl = url.replace('https://cdn.jsdelivr.net/', 'https://purge.jsdelivr.net/');
  try {
    await fetch(purgeUrl, { signal: AbortSignal.timeout(6000) });
  } catch (err) { /* 清缓存失败不影响流程 */ }
}

function versionValue(v) {
  const m = String(v || '').match(/(\d+)\.(\d+)/);
  return m ? Number(m[1]) * 1000 + Number(m[2]) : 0;
}

async function fetchOneManifest(url) {
  await purgeCdn(url);
  const res = await fetch(url, {
    cache: 'no-store',
    signal: AbortSignal.timeout(10000),
    headers: { 'Cache-Control': 'no-cache', Pragma: 'no-cache' }
  });
  if (!res.ok) throw new Error('返回 ' + res.status);
  const data = await res.json();
  if (!data || !data.version) throw new Error('清单格式不对');
  return data;
}

/** 依次访问所有来源，取版本号最高的那份清单 */
async function fetchManifest() {
  const cfg = readUpdateConfig();
  if (!cfg.checkUrls.length) throw new Error('没有配置更新地址（update.json 里的 checkUrls）');
  const results = await Promise.all(cfg.checkUrls.map(async (url) => {
    try {
      return { url, manifest: await fetchOneManifest(url) };
    } catch (err) {
      return { url, error: err.message };
    }
  }));
  const ok = results.filter((r) => r.manifest);
  if (!ok.length) {
    const detail = results.map((r) => r.error).filter(Boolean).join('；');
    throw new Error('所有更新地址都访问失败：' + detail);
  }
  ok.sort((a, b) => versionValue(b.manifest.version) - versionValue(a.manifest.version));
  return { manifest: ok[0].manifest, config: cfg, source: ok[0].url };
}

async function checkUpdate() {
  const { manifest } = await fetchManifest();
  const latest = String(manifest.version);
  return {
    current: APP_VERSION,
    latest,
    hasUpdate: versionValue(latest) > versionValue(APP_VERSION),
    notes: String(manifest.notes || ''),
    date: String(manifest.date || ''),
    url: String(manifest.zip || ''),
  };
}

function unzipBuffer(buf) {
  const dv = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  let eocd = -1;
  for (let i = buf.length - 22; i >= 0 && i > buf.length - 65558; i--) {
    if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) throw new Error('不是有效的压缩包');
  const count = dv.getUint16(eocd + 10, true);
  let off = dv.getUint32(eocd + 16, true);
  const out = [];
  for (let i = 0; i < count; i++) {
    if (off + 46 > buf.length || dv.getUint32(off, true) !== 0x02014b50) break;
    const method = dv.getUint16(off + 10, true);
    const compSize = dv.getUint32(off + 20, true);
    const nameLen = dv.getUint16(off + 28, true);
    const extraLen = dv.getUint16(off + 30, true);
    const commentLen = dv.getUint16(off + 32, true);
    const localOff = dv.getUint32(off + 42, true);
    const name = buf.subarray(off + 46, off + 46 + nameLen).toString('utf8');
    if (localOff + 30 <= buf.length) {
      const lNameLen = dv.getUint16(localOff + 26, true);
      const lExtraLen = dv.getUint16(localOff + 28, true);
      const start = localOff + 30 + lNameLen + lExtraLen;
      const raw = buf.subarray(start, start + compSize);
      out.push({ name, data: method === 0 ? Buffer.from(raw) : zlib.inflateRawSync(raw) });
    }
    off += 46 + nameLen + extraLen + commentLen;
  }
  return out;
}

async function applyUpdate() {
  const { manifest } = await fetchManifest();
  const latest = String(manifest.version);
  if (versionValue(latest) <= versionValue(APP_VERSION)) {
    return { ok: true, updated: false, current: APP_VERSION, latest, message: '已经是最新版本' };
  }
  const zipUrl = String(manifest.zip || '');
  if (!/^https?:\/\//.test(zipUrl)) throw new Error('更新清单里的 zip 地址无效');

  const res = await fetch(zipUrl, { cache: 'no-store', signal: AbortSignal.timeout(120000) });
  if (!res.ok) throw new Error('下载更新包失败 ' + res.status);
  const buf = Buffer.from(await res.arrayBuffer());
  const entries = unzipBuffer(buf);

  // 压缩包里通常有一个「记账本」根目录，先定位它
  let prefix = '';
  const serverEntry = entries.filter((e) => /(^|\/)server\.js$/.test(e.name))[0];
  if (!serverEntry) throw new Error('压缩包里没有 server.js');
  prefix = serverEntry.name.slice(0, serverEntry.name.length - 'server.js'.length);

  // 先备份数据
  try {
    if (fs.existsSync(DATA_FILE)) {
      const bkDir = path.join(DATA_DIR, 'backups');
      fs.mkdirSync(bkDir, { recursive: true });
      const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
      fs.copyFileSync(DATA_FILE, path.join(bkDir, 'ledger-before-update-' + stamp + '.json'));
    }
  } catch (err) {
    console.error('[warn] 更新前备份失败:', err.message);
  }

  const replaced = [];
  for (const entry of entries) {
    if (!entry.name || entry.name.endsWith('/')) continue;
    const rel = entry.name.slice(prefix.length);
    if (!rel) continue;
    if (!UPDATE_ALLOW.some((re) => re.test(rel))) continue;
    const dest = path.join(ROOT, rel);
    if (!dest.startsWith(ROOT)) continue;
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.writeFileSync(dest, entry.data);
    replaced.push(rel);
  }
  if (!replaced.length) throw new Error('压缩包里没有可替换的文件');
  return { ok: true, updated: true, current: APP_VERSION, latest, files: replaced.length };
}

function scheduleRestart() {
  setTimeout(() => {
    console.log('更新完成，服务即将重启…');
    process.exit(0);
  }, 800);
}
// ---------------------------------------------------------------------------
// 静态文件
// ---------------------------------------------------------------------------

function serveStatic(req, res, urlPath) {
  let rel = decodeURIComponent(urlPath);
  if (rel === '/' || rel === '') rel = '/index.html';
  const target = path.join(PUBLIC_DIR, path.normalize(rel).replace(/^([/\\])+/, ''));
  if (!target.startsWith(PUBLIC_DIR)) return send(res, 403, { error: '禁止访问' });
  fs.readFile(target, (err, buf) => {
    if (err) {
      // 单页应用: 未知的无后缀路径回退到 index.html
      if (!path.extname(target)) {
        fs.readFile(path.join(PUBLIC_DIR, 'index.html'), (e2, html) => {
          if (e2) return send(res, 404, { error: 'Not Found' });
          res.writeHead(200, { 'Content-Type': MIME['.html'] }).end(html);
        });
        return;
      }
      return send(res, 404, { error: 'Not Found' });
    }
    const ext = path.extname(target).toLowerCase();
    const dynamic = ['.html', '.js', '.css', '.webmanifest'].includes(ext) || target.endsWith('sw.js');
    res.writeHead(200, {
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'Cache-Control': dynamic ? 'no-store, must-revalidate' : 'public, max-age=3600',
    });
    res.end(buf);
  });
}

// ---------------------------------------------------------------------------
// 路由
// ---------------------------------------------------------------------------

function unauthorized(res) {
  send(res, 401, { error: '需要访问口令', needCode: true });
}

function checkCode(req, url) {
  if (!ACCESS_CODE) return true;
  const header = req.headers['x-access-code'];
  const q = url.searchParams.get('code');
  const cookie = /(?:^|;\s*)ledger_code=([^;]+)/.exec(req.headers.cookie || '');
  const cookieVal = cookie ? decodeURIComponent(cookie[1]) : '';
  return header === ACCESS_CODE || q === ACCESS_CODE || cookieVal === ACCESS_CODE;
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = url.pathname;

  if (pathname.startsWith('/api/')) {
    // 携带正确口令时写入 Cookie，方便手机端后续免输
    if (ACCESS_CODE && url.searchParams.get('code') === ACCESS_CODE) {
      res.setHeader(
        'Set-Cookie',
        `ledger_code=${encodeURIComponent(ACCESS_CODE)}; Path=/; Max-Age=31536000; SameSite=Lax`
      );
    }

    if (pathname === '/api/health' && req.method === 'GET') {
      return send(res, 200, {
        ok: true,
        app: 'ledger',
        version: 2,
        needCode: Boolean(ACCESS_CODE),
        icp: ICP_BEIAN,
        port: PORT,
        appVersion: APP_VERSION,
        addresses: localAddresses(),
      });
    }

    if (!checkCode(req, url)) return unauthorized(res);

    if (pathname === '/api/state' && req.method === 'GET') {
      return send(res, 200, db);
    }

    if (pathname === '/api/ops' && req.method === 'POST') {
      try {
        const body = await readBody(req);
        const ops = Array.isArray(body.ops) ? body.ops : [];
        if (!ops.length) return send(res, 400, { error: '没有要执行的改动' });
        applyOps(ops);
        broadcast('change', { rev: db.rev, updatedAt: db.updatedAt, count: db.transactions.length });
        return send(res, 200, { ok: true, rev: db.rev, count: db.transactions.length });
      } catch (err) {
        return send(res, 400, { error: err.message });
      }
    }

    if (pathname === '/api/save' && req.method === 'POST') {
      saveDbNow();
      return send(res, 200, { ok: true, saved: db.transactions.length });
    }

    if (pathname === '/api/update/check' && req.method === 'GET') {
      try {
        const info = await checkUpdate();
        return send(res, 200, Object.assign({ ok: true }, info));
      } catch (err) {
        return send(res, 200, { ok: false, error: err.message, current: APP_VERSION });
      }
    }

    if (pathname === '/api/update/apply' && req.method === 'POST') {
      try {
        const result = await applyUpdate();
        if (result.updated) scheduleRestart();
        return send(res, 200, result);
      } catch (err) {
        return send(res, 400, { ok: false, error: err.message });
      }
    }

    if (pathname === '/api/events' && req.method === 'GET') {
      res.writeHead(200, {
        'Content-Type': 'text/event-stream; charset=utf-8',
        'Cache-Control': 'no-cache, no-transform',
        Connection: 'keep-alive',
        'X-Accel-Buffering': 'no',
      });
      res.write('retry: 3000\n\n');
      res.write(`event: ready\ndata: ${JSON.stringify({ rev: db.rev })}\n\n`);
      clients.add(res);
      req.on('close', () => clients.delete(res));
      return;
    }

    return send(res, 404, { error: 'Not Found' });
  }

  if (req.method !== 'GET' && req.method !== 'HEAD') {
    return send(res, 405, { error: 'Method Not Allowed' });
  }
  return serveStatic(req, res, pathname);
});

// ---------------------------------------------------------------------------
// 启动
// ---------------------------------------------------------------------------

loadDb();

function localAddresses() {
  const out = [];
  for (const list of Object.values(os.networkInterfaces())) {
    for (const ni of list || []) {
      if (ni.family === 'IPv4' && !ni.internal) out.push(ni.address);
    }
  }
  return out;
}

server.listen(PORT, HOST, () => {
  const lines = [
    '',
    '  记账本已启动',
    '',
    `  这台电脑:       http://localhost:${PORT}`,
    ...localAddresses().map((ip) => `  手机(同一WiFi):  http://${ip}:${PORT}`),
    '',
    `  数据文件:       ${DATA_FILE}`,
    `  访问口令:       ${ACCESS_CODE ? '已开启' : '未开启 (设置 ACCESS_CODE 环境变量可开启)'}`,
    '',
    '  按 Ctrl + C 停止',
    '',
  ];
  console.log(lines.join('\n'));
});

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error('');
    console.error('  端口 ' + PORT + ' 已被占用：记账本很可能已经在运行。');
    console.error('  直接打开 http://localhost:' + PORT + ' 就能用。');
    console.error('  想换端口：set PORT=9000 && node server.js');
    console.error('');
  } else {
    console.error('');
    console.error('  启动失败: ' + err.message);
    console.error('');
  }
  process.exit(1);
});

process.on('SIGINT', () => {
  saveDbNow();
  console.log('\n数据已保存，记账本已停止。');
  process.exit(0);
});
