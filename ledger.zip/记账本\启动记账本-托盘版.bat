@echo off
cd /d "%~dp0"
start "Ledger" /min powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0tray.ps1"
