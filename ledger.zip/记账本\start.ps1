﻿# 记账本 · Windows 启动脚本
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $root
try { $Host.UI.RawUI.WindowTitle = '记账本' } catch {}
$port = '8787'
if ($env:PORT) { $port = $env:PORT }
$url = 'http://localhost:' + $port

function Find-Node {
  $cmd = Get-Command node -ErrorAction SilentlyContinue
  if ($cmd -and $cmd.Source) { return $cmd.Source }
  $cands = @(
    (Join-Path $env:ProgramFiles 'nodejs\node.exe'),
    (Join-Path $env:LOCALAPPDATA 'Programs\nodejs\node.exe')
  )
  foreach ($c in $cands) { if ($c -and (Test-Path -LiteralPath $c)) { return $c } }
  $pattern = Join-Path $env:USERPROFILE '.cache\codex-runtimes\*\dependencies\node\bin\node.exe'
  $hit = Get-ChildItem -Path $pattern -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($hit) { return $hit.FullName }
  return $null
}

$nodePath = Find-Node

if (-not $nodePath) {
  Write-Host ''
  Write-Host '  没有检测到 Node.js，先帮你打开「本机版」。'
  Write-Host '  本机版能正常记账和看分析，但数据存在这个浏览器里，电脑和手机不能同步。'
  Write-Host ''
  Write-Host '  想实现电脑 + 手机实时同步，需要安装 Node.js（约 30MB，2 分钟）。'
  Write-Host '  下载地址和步骤见同目录下的 使用说明.txt。'
  Write-Host ''
  $localPage = Join-Path $root 'public\index.html'
  if (Test-Path -LiteralPath $localPage) { try { Start-Process $localPage } catch {} }
  exit 1
}

Write-Host ''
Write-Host '  正在启动记账本...'
if ($nodePath -like '*codex-runtimes*') {
  Write-Host '  提示：当前用的是 Codex 自带的 Node 运行时，建议以后自己装一个 Node.js。'
}
Write-Host ('  电脑打开: ' + $url)
Write-Host '  手机访问: 同一个 WiFi 下，打开下面显示的「同一WiFi」地址'
Write-Host '  停止服务: 在本窗口按 Ctrl + C'   # 浏览器没自动弹出时，手动打开上面那个地址即可
Write-Host ''

# 2 秒后自动打开浏览器（失败也不影响服务启动）
if (-not $env:LEDGER_NO_OPEN) {
  try {
    $inner = "Start-Sleep -Seconds 2; Start-Process '" + $url + "'"
    $encoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($inner))
    $null = & cmd.exe /c ('start "" powershell -NoProfile -WindowStyle Hidden -EncodedCommand ' + $encoded)
  } catch { }
}

try {
  & $nodePath (Join-Path $root 'server.js')
} catch {
  Write-Host ''
  Write-Host ('  启动出错: ' + $_.Exception.Message)
  Write-Host '  可以把这段文字截图发给 Codex。'
}

Write-Host ''
Write-Host '  记账本已停止。'
