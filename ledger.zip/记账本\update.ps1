﻿# 记账本 · 更新程序
# 作用：把新版压缩包里的“程序文件”替换到当前目录，账目数据（data 文件夹）原样保留
param([string]$ZipPath)

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$lines = @()
function Say($text) { $script:lines += $text; Write-Host $text }

Say '=========================================='
Say '记账本 · 程序更新'
Say '=========================================='
Say ''

# 1) 找新版本压缩包
if (-not $ZipPath) {
  $cands = Get-ChildItem -LiteralPath $root -Filter '记账本*.zip' -File -ErrorAction SilentlyContinue |
           Sort-Object LastWriteTime -Descending
  if ($cands.Count -gt 0) { $ZipPath = $cands[0].FullName }
}
if (-not $ZipPath -or -not (Test-Path -LiteralPath $ZipPath)) {
  Say '× 没有找到新版压缩包。'
  Say '  请把新的「记账本-xxx.zip」放到本文件夹（和这个脚本同一个目录），再运行一次。'
  Read-Host '按回车键关闭'
  exit 1
}
Say ('新版压缩包：' + (Split-Path -Leaf $ZipPath))

# 2) 先备份账目数据
$dataDir = Join-Path $root 'data'
$dataFile = Join-Path $dataDir 'ledger.json'
if (Test-Path -LiteralPath $dataFile) {
  $bkDir = Join-Path $dataDir 'backups'
  if (-not (Test-Path -LiteralPath $bkDir)) { New-Item -ItemType Directory -Force -Path $bkDir | Out-Null }
  Copy-Item -LiteralPath $dataFile -Destination (Join-Path $bkDir ('ledger-' + $stamp + '.json'))
  Say ('✓ 已备份数据到 data\backups\ledger-' + $stamp + '.json')
} else {
  Say '（还没有账目数据，跳过备份）'
}
Say ''

# 3) 解压新版本到临时目录
$temp = Join-Path $env:TEMP ('ledger-update-' + $stamp)
New-Item -ItemType Directory -Force -Path $temp | Out-Null
Say '正在解压新版本…'
Expand-Archive -LiteralPath $ZipPath -DestinationPath $temp -Force

# 找到解压出来的程序目录（压缩包里是「记账本」文件夹）
$src = $temp
$sub = Get-ChildItem -LiteralPath $temp -Directory | Where-Object { Test-Path (Join-Path $_.FullName 'server.js') } | Select-Object -First 1
if ($sub) { $src = $sub.FullName }
if (-not (Test-Path -LiteralPath (Join-Path $src 'server.js'))) {
  Say '× 压缩包里没有找到程序文件（server.js）。'
  Read-Host '按回车键关闭'
  exit 1
}

# 4) 覆盖程序文件（不碰 data 文件夹）
$items = @('server.js', 'public', 'tray.ps1', 'start.ps1', 'app.ico', '导入模板.csv',
           '启动记账本-托盘版.bat', '启动记账本.bat', 'README.md', '使用说明.txt')
$copied = 0
foreach ($item in $items) {
  $from = Join-Path $src $item
  if (-not (Test-Path -LiteralPath $from)) { continue }
  $to = Join-Path $root $item
  if (Test-Path -LiteralPath $to) { Remove-Item -LiteralPath $to -Recurse -Force }
  Copy-Item -LiteralPath $from -Destination $to -Recurse -Force
  Say ('  更新 ' + $item)
  $copied++
}
Remove-Item -LiteralPath $temp -Recurse -Force -ErrorAction SilentlyContinue

Say ''
Say ('✓ 更新完成，共替换 ' + $copied + ' 项')
Say '  账目数据（data 文件夹）没有被改动'
Say ''
Say '接下来：'
Say '  1) 如果记账本正在运行，右键右下角托盘图标 →“退出（停止服务）”'
Say '  2) 再双击桌面上的「记账本」启动即可'
Say '  3) 打开后看左侧栏最下方的版本号，确认已经更新'
Say ''
Read-Host '按回车键关闭'