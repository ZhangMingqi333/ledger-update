﻿# 记账本 · 托盘启动器（纯 PowerShell，不依赖 exe，避免被“智能应用控制”拦截）
param([switch]$NoBrowser)

# 出错时把原因写到 tray-error.log，方便排查
trap {
  $logPath = Join-Path $PSScriptRoot 'tray-error.log'
  $msg = '时间: ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + "`n" + $_.Exception.Message + "`n" + $_.ScriptStackTrace
  try { Set-Content -LiteralPath $logPath -Value $msg -Encoding UTF8 } catch { }
  exit 1
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$ErrorActionPreference = 'Stop'

$root = $PSScriptRoot
Set-Location -LiteralPath $root
$port = if ($env:PORT) { $env:PORT } else { '8787' }
$url = "http://localhost:$port"

function Find-Node {
  $bundled = Join-Path $root 'node\node.exe'
  if (Test-Path -LiteralPath $bundled) { return $bundled }
  $cands = @(
    (Join-Path $env:ProgramFiles 'nodejs\node.exe'),
    (Join-Path $env:LOCALAPPDATA 'Programs\nodejs\node.exe')
  )
  foreach ($c in $cands) { if ($c -and (Test-Path -LiteralPath $c)) { return $c } }
  $pattern = Join-Path $env:USERPROFILE '.cache\codex-runtimes\*\dependencies\node\bin\node.exe'
  $hit = Get-ChildItem -Path $pattern -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($hit) { return $hit.FullName }
  $cmd = Get-Command node -ErrorAction SilentlyContinue
  if ($cmd) { return $cmd.Source }
  return $null
}

function Test-Server {
  try {
    $r = Invoke-WebRequest -Uri "http://127.0.0.1:$port/api/health" -TimeoutSec 1 -UseBasicParsing
    return ($r.StatusCode -eq 200)
  } catch { return $false }
}

function Get-PhoneText {
  $lines = @()
  $ips = @()
  try {
    foreach ($ni in [System.Net.NetworkInformation.NetworkInterface]::GetAllNetworkInterfaces()) {
      if ($ni.OperationalStatus -ne 'Up') { continue }
      if ($ni.NetworkInterfaceType -eq 'Loopback') { continue }
      foreach ($ip in $ni.GetIPProperties().UnicastAddresses) {
        if ($ip.Address.AddressFamily -ne 'InterNetwork') { continue }
        $s = $ip.Address.ToString()
        if ($s.StartsWith('127.') -or $s.StartsWith('169.254.')) { continue }
        if ($ips -notcontains $s) { $ips += $s }
      }
    }
  } catch { }
  $lan = $ips | Where-Object { $_ -notmatch '^100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\.' } | Select-Object -First 1
  $ts = $ips | Where-Object { $_ -match '^100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\.' } | Select-Object -First 1
  if ($lan) { $lines += ('同一 WiFi：http://' + $lan + ':' + $port) }
  if ($ts) { $lines += ('Tailscale：http://' + $ts + ':' + $port) }
  if (-not $lines.Count) { $lines += ("http://localhost:$port") }
  return ($lines -join "`n")
}

# 防止重复启动（重复双击时只打开浏览器，不再多出一个托盘图标）
$trayMutex = New-Object System.Threading.Mutex($false, 'Global\LedgerTrayMutex')
$isFirst = $false
try { $isFirst = $trayMutex.WaitOne(0) } catch { $isFirst = $true }
if (-not $isFirst) {
  try { Start-Process $url } catch { }
  exit 0
}

$nodePath = Find-Node
if (-not $nodePath) {
  [System.Windows.Forms.MessageBox]::Show("没有找到 Node.js。`n`n请先到 https://nodejs.org 安装 LTS 版本，再重新双击启动。", '记账本') | Out-Null
  exit 1
}

$serverProc = $null
$startedByUs = $false
if (-not (Test-Server)) {
  $serverProc = Start-Process -FilePath $nodePath -ArgumentList ('"' + (Join-Path $root 'server.js') + '"') -WorkingDirectory $root -WindowStyle Hidden -PassThru
  $startedByUs = $true
  for ($i = 0; $i -lt 40; $i++) {
    if (Test-Server) { break }
    Start-Sleep -Milliseconds 500
  }
}

# ---------- 托盘图标 ----------
$notify = New-Object System.Windows.Forms.NotifyIcon
$icoPath = Join-Path $root 'app.ico'
if (Test-Path -LiteralPath $icoPath) {
  try { $notify.Icon = New-Object System.Drawing.Icon($icoPath) } catch { $notify.Icon = [System.Drawing.SystemIcons]::Application }
} else {
  $notify.Icon = [System.Drawing.SystemIcons]::Application
}
$notify.Text = '记账本 · 运行中'
$notify.Visible = $true

$context = New-Object System.Windows.Forms.ApplicationContext

$menu = New-Object System.Windows.Forms.ContextMenu

$miOpen = New-Object System.Windows.Forms.MenuItem('打开记账本')
$miOpen.add_Click({ try { Start-Process $url } catch { } })
$menu.MenuItems.Add($miOpen) | Out-Null

$miPhone = New-Object System.Windows.Forms.MenuItem('复制手机访问地址')
$miPhone.add_Click({
  $text = Get-PhoneText
  try { [System.Windows.Forms.Clipboard]::SetText($text) } catch { }
  $notify.ShowBalloonTip(5000, '手机访问地址已复制', $text, [System.Windows.Forms.ToolTipIcon]::Info)
})
$menu.MenuItems.Add($miPhone) | Out-Null

$miData = New-Object System.Windows.Forms.MenuItem('打开数据文件夹')
$miData.add_Click({
  $dir = Join-Path $root 'data'
  if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
  try { Start-Process explorer.exe $dir } catch { }
})
$menu.MenuItems.Add($miData) | Out-Null

$menu.MenuItems.Add('-') | Out-Null

$runKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
$miAuto = New-Object System.Windows.Forms.MenuItem('开机自动启动')
$autoCmd = 'wscript.exe "' + (Join-Path $root '启动记账本-托盘版.vbs') + '"'
try { $miAuto.Checked = ((Get-ItemProperty -Path $runKey -Name 'LedgerBook' -ErrorAction SilentlyContinue) -ne $null) } catch { }
$miAuto.add_Click({
  try {
    if ($miAuto.Checked) {
      Remove-ItemProperty -Path $runKey -Name 'LedgerBook' -ErrorAction SilentlyContinue
      $miAuto.Checked = $false
      $notify.ShowBalloonTip(3000, '记账本', '已取消开机自动启动', [System.Windows.Forms.ToolTipIcon]::Info)
    } else {
      Set-ItemProperty -Path $runKey -Name 'LedgerBook' -Value $autoCmd
      $miAuto.Checked = $true
      $notify.ShowBalloonTip(3000, '记账本', '已设置为开机自动启动', [System.Windows.Forms.ToolTipIcon]::Info)
    }
  } catch {
    [System.Windows.Forms.MessageBox]::Show('设置失败：' + $_.Exception.Message, '记账本') | Out-Null
  }
})
$menu.MenuItems.Add($miAuto) | Out-Null

$menu.MenuItems.Add('-') | Out-Null

$miExit = New-Object System.Windows.Forms.MenuItem('退出（停止服务）')
$miExit.add_Click({
  $notify.Visible = $false
  $notify.Dispose()
  if ($startedByUs -and $serverProc -and -not $serverProc.HasExited) {
    try { Invoke-WebRequest -Uri "http://127.0.0.1:$port/api/save" -Method POST -TimeoutSec 2 -UseBasicParsing | Out-Null } catch { }
    Start-Sleep -Milliseconds 150
    try { $serverProc.Kill() } catch { }
  }
  $context.ExitThread()
})
$menu.MenuItems.Add($miExit) | Out-Null

$notify.ContextMenu = $menu
$notify.add_DoubleClick({ try { Start-Process $url } catch { } })

if (-not $NoBrowser) { try { Start-Process $url } catch { } }

$ready = Test-Server
if ($ready) {
  try { $notify.ShowBalloonTip(5000, '记账本已启动', ('手机访问地址：' + "`n" + (Get-PhoneText)), [System.Windows.Forms.ToolTipIcon]::Info) } catch { }
} else {
  try { $notify.ShowBalloonTip(5000, '记账本启动中', '服务正在启动，几秒后再试', [System.Windows.Forms.ToolTipIcon]::Warning) } catch { }
}

# 后台看护：服务意外退出（比如自动更新替换文件后）会自动重启
$watch = New-Object System.Windows.Forms.Timer
$watch.Interval = 5000
$watch.add_Tick({
  try {
    if ($startedByUs -and $serverProc -and $serverProc.HasExited) {
      Start-Sleep -Milliseconds 800
      $script:serverProc = Start-Process -FilePath $nodePath -ArgumentList ('"' + (Join-Path $root 'server.js') + '"') -WorkingDirectory $root -WindowStyle Hidden -PassThru
      try { $notify.ShowBalloonTip(3000, '记账本', '服务已自动重启', [System.Windows.Forms.ToolTipIcon]::Info) } catch { }
    }
  } catch { }
})
$watch.Start()

[System.Windows.Forms.Application]::Run($context)